package com.crudzao.creditapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CreditApplicationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
