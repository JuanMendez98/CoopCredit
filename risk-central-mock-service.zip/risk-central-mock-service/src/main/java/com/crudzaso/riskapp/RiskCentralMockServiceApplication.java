package com.crudzaso.riskapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RiskCentralMockServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RiskCentralMockServiceApplication.class, args);
	}

}
